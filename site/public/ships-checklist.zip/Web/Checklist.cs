namespace Ship.Web;

public record Item(int Id, string Title, bool Complete = false);

public class ChecklistProvider : Caravel.Core.ServiceProvider
{
    public override void Register(IServiceCollection services) =>
        services.AddSingleton<Checklist>();
}

public class Checklist
{
    private readonly List<Item> items = [new(1, "Check the weather")];
    private readonly object gate = new();
    public Item[] All()
    {
        lock (gate) return items.ToArray();
    }
    public void Add(string title)
    {
        lock (gate) items.Add(new(items.Count + 1, title));
    }
    public bool SetComplete(int id, bool complete)
    {
        lock (gate)
        {
            int index = items.FindIndex(item => item.Id == id);
            if (index < 0) return false;
            items[index] = items[index] with { Complete = complete };
            return true;
        }
    }
}
