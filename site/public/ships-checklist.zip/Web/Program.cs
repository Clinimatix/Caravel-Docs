using Caravel.AspNetCore;
using Ship.Web;

var builder = WebApplication.CreateBuilder(args);
builder.AddCaravel(options => options.AddProvider<ChecklistProvider>());
builder.Services.AddRazorPages();
var app = builder.Build();
app.UseStaticFiles();
app.UseCaravel();
app.MapRazorPages();
if (await app.ExportCaravelRoutesAsync(args)) return;
await app.RunAsync();
