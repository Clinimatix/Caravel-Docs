using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ship.Web;

public class IndexModel(Checklist checklist) : PageModel
{
    public Item[] Items => checklist.All();
    [BindProperty] public string? Title { get; set; }
    public IActionResult OnPostAdd()
    {
        var title = Title?.Trim();
        if (string.IsNullOrEmpty(title) || title.Length > 80)
        {
            ModelState.AddModelError(nameof(Title), "Enter a task between 1 and 80 characters.");
            return Page();
        }
        checklist.Add(title);
        return RedirectToPage();
    }

    public IActionResult OnPostStatus(int id, bool complete) =>
        checklist.SetComplete(id, complete) ? RedirectToPage() : NotFound();
}
