using Caravel.AspNetCore;
using Caravel.Clarion;
using Microsoft.EntityFrameworkCore;

bool initialize = args is ["init"];
var builder = WebApplication.CreateBuilder(initialize ? Array.Empty<string>() : args);
builder.AddCaravel();
builder.Services.AddClarion<ChecklistDb>(options => options.UseSqlite(initialize
    ? "Data Source=checklist.db" : "Data Source=checklist.db;Mode=ReadWrite"));
var app = builder.Build();
if (initialize)
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<ChecklistDb>();
    await db.Database.EnsureCreatedAsync();
    Console.WriteLine("Checklist database ready.");
    return;
}
app.UseCaravel();
app.Routes(routes => routes.Get("/", () => "Ship’s Checklist API").Name("home"));
app.MapGet("/tasks", async (IClarion db, CancellationToken ct) =>
    await db.Models<ChecklistItem>().AsNoTracking().OrderBy(x => x.Id).GetAsync(ct));
app.MapGet("/tasks/{id:int}", async (int id, IClarion db, CancellationToken ct) =>
    await db.Models<ChecklistItem>().FindAsync([id], ct) is { } item
        ? Results.Ok(item) : Results.NotFound());
app.MapPost("/tasks", async (NewTask input, IClarion db, CancellationToken ct) =>
{
    var title = input.Title?.Trim();
    if (string.IsNullOrEmpty(title) || title.Length > 80)
        return Results.BadRequest("Enter a task between 1 and 80 characters.");
    var item = new ChecklistItem { Title = title };
    db.Models<ChecklistItem>().Add(item);
    await db.SaveChangesAsync(ct);
    return Results.Created($"/tasks/{item.Id}", item);
});
app.MapPut("/tasks/{id:int}/complete", async (int id, IClarion db, CancellationToken ct) =>
{
    var item = await db.Models<ChecklistItem>().FindAsync([id], ct);
    if (item is null) return Results.NotFound();
    item.Complete = true;
    await db.SaveChangesAsync(ct);
    return Results.Ok(item);
});
if (await app.ExportCaravelRoutesAsync(args)) return;
await app.RunAsync();

record NewTask(string? Title);
class ChecklistItem
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public bool Complete { get; set; }
}
class ChecklistDb(DbContextOptions<ChecklistDb> options) : DbContext(options)
{
    public DbSet<ChecklistItem> Tasks => Set<ChecklistItem>();
}
